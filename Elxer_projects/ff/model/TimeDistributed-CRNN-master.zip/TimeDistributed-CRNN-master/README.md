# TimeDistributed-CRNN
To try CTC in Keras
