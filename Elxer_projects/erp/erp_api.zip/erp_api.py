from flask import Flask, jsonify, request
import requests
import mysql.connector

database = mysql.connector.connect(
    host="localhost",
    user="root",
    password="12345")
database_cursor = database.cursor()
database_cursor.execute("create database if not exists erp")
database_cursor.execute("use erp")
database_cursor.execute("CREATE TABLE IF NOT EXISTS user_data(name varchar(40),phone_number bigint UNIQUE NOT NULL,email varchar(60) UNIQUE NOT NULL,password varchar(30))")

app = Flask(__name__)

@app.route('/', methods=['POST'])
def hi():
    return "Welcome to School ERP"


@app.route('/login', methods=['POST'])
def login():
    data=request.json
    email=data.get("email")
    print("email:",email)
    password=data.get("password")
    phone_number=data.get("contact")
    print("phone_number:",phone_number)
    
    def check(passw):
        
        pwd=passw
        print(password)
        if password==None:
            return "Password feild cannot be empty"
        
        elif pwd==password:
            return "Verified User"
        
        elif pwd!=password:
            return "Incorrect Password"
        
        else:
            return "User Not Found"
    
    if database.is_connected():
        try:
            if phone_number==None and len(email)>0:
                cursor=database.cursor()
                query = f"SELECT password FROM user_data WHERE email = '{email}'"
                cursor.execute(query)
                
                rows = cursor.fetchall()
                passw=rows[0][0]
                result=check(passw)
                return result
                
            elif email==None and len(str(phone_number))>0:
                print("NO")
                cursor=database.cursor()
                query = f"SELECT password FROM user_data WHERE phone_number = '{phone_number}'"
                cursor.execute(query)
                
                rows = cursor.fetchall()
                passw=rows[0][0]
                print(passw)
                result=check(passw)
                return result
            
            
        except Exception as e:
            print("e")
            err=str(e)
            print(err)
            if "'NoneType'" in err:
                return "Id feild cannot be empty"
            
            elif "list index out of range" in err:
                return "Incorrect User ID"
            
            else:
                return err
        


@app.route('/forgot_password', methods=['POST'])
def forgot_password():
    print("forgot_password")
    return "forgot_password"


@app.route('/register', methods=['POST'])
def register():
    data=request.json
    name=data.get("name")
    phone_number=data.get("contact")
    email=data.get("email")
    password=data.get("password")
    
    if database.is_connected():
        try:    
            if name
            cursor=database.cursor()
            query = "INSERT INTO user_data (name, phone_number, email,password) VALUES (%s, %s, %s, %s)"
            values = (name, phone_number, email,password)
            cursor.execute(query, values)
            database.commit()
            
            db={"Name":name, "Contact":phone_number,"Email": email}
            return db
        
        except Exception as e:
            
            excp=str(e).split(" ")
            print(excp[-1])
            if excp[-1]=="'user_data.phone_number'":
                return {"error":"Contact already exists"}
            elif excp[-1]=="'user_data.email'":
                return {"error":"Email already exists"}
            else:
                return {"error":e}
            
    
if __name__ == '__main__':
    app.run(debug=True)